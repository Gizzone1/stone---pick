# Favorita Stone Pick

App interna per valutare nuovi materiali con il team commerciale.

---

## PASSO 1 — Database Supabase

1. Vai su https://supabase.com → apri il tuo progetto
2. Menu → **SQL Editor → New query**
3. Copia tutto il contenuto di `supabase_setup.sql` → **Run**
4. Dovresti vedere "Success"

---

## PASSO 2 — Carica su GitHub

1. Vai su https://github.com → **New repository** → nome `stone-pick` → Create
2. Clicca **"uploading an existing file"**
3. Decomprimi lo zip e carica **tutti i file** (inclusa la cartella `src/`)
4. **Commit changes**

---

## PASSO 3 — Deploy su Vercel

1. Vai su https://vercel.com → **Sign up with GitHub**
2. **Add New → Project** → seleziona `stone-pick` → **Deploy**
3. In ~1 minuto hai il link tipo `stone-pick.vercel.app`

---

## Credenziali

- **PIN Admin**: `1234`
- **Venditori**: si registrano con il codice generato dall'Admin

---

## Note

- I dati (proposte, voti) sono su Supabase
- La lista venditori è salvata localmente nel browser dell'Admin
- Le foto sono salvate come base64 nel database (max ~5MB per proposta)
