-- Esegui questo script nel SQL Editor di Supabase
-- Database → SQL Editor → New query → incolla tutto → Run

CREATE TABLE proposals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  format TEXT NOT NULL,
  price TEXT,
  sale_price TEXT,
  size TEXT,
  notes TEXT,
  video_url TEXT,
  images JSONB DEFAULT '[]',
  audience TEXT DEFAULT 'all',
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE votes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  proposal_id UUID REFERENCES proposals(id) ON DELETE CASCADE,
  seller_name TEXT NOT NULL,
  vote TEXT NOT NULL CHECK (vote IN ('yes', 'no')),
  comment TEXT,
  voted_at TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(proposal_id, seller_name)
);

ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "read proposals" ON proposals FOR SELECT USING (true);
CREATE POLICY "insert proposals" ON proposals FOR INSERT WITH CHECK (true);
CREATE POLICY "update proposals" ON proposals FOR UPDATE USING (true);
CREATE POLICY "delete proposals" ON proposals FOR DELETE USING (true);

CREATE POLICY "read votes" ON votes FOR SELECT USING (true);
CREATE POLICY "insert votes" ON votes FOR INSERT WITH CHECK (true);
CREATE POLICY "update votes" ON votes FOR UPDATE USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE proposals;
ALTER PUBLICATION supabase_realtime ADD TABLE votes;
